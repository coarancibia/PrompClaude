# Ejemplo general de uso

Esta skill sirve para migrar, actualizar o crear cualquier componente. El tipo de componente se detecta desde el enlace o desde la descripción y la auditoría se adapta a su función.

## Fuentes permanentes del sistema

La usuaria no debe volver a pegarlas al invocar la skill.

- **DS Token · Prime:** variables, modo Light, spacing, radios, sizing, efectos e iconografía oficial.
- **DS Components · Prime:** Text Styles, átomos, moléculas, organismos, component sets, variantes y propiedades.
- **Superficie permanente:** Light sobre fondo blanco.

## Migrar o actualizar un componente

```text
/editar-componente-figma-ds

Componente a migrar:
<link exacto al componente o component set>

Objetivo:
Actualizarlo al DS vigente manteniendo su función, estructura, variantes y comportamiento responsive.
```

## Crear un componente nuevo

```text
/editar-componente-figma-ds

Componente a crear:
<descripción de la función, contenido, contexto de uso y estados necesarios>
```

## Respuesta esperada de Claude

Antes de modificar Figma, Claude debe entregar:

1. alcance detectado y clasificación como átomo, molécula u organismo;
2. búsqueda de equivalencias existentes en DS Components · Prime;
3. elementos oficiales que reutilizará;
4. problemas encontrados o necesidades no cubiertas;
5. tabla de mapeo con tokens reales;
6. Text Styles obtenidos desde DS Components · Prime;
7. iconos y variables obtenidos desde DS Token · Prime;
8. revisión de accesibilidad en Light / fondo blanco;
9. plan de ejecución;
10. solicitud de aprobación.

La respuesta debe terminar con:

```text
No he modificado Figma. ¿Qué deseas hacer?
1. APROBAR COPIA
2. AJUSTAR PROPUESTA
3. EDITAR ORIGINAL
4. CANCELAR
```
