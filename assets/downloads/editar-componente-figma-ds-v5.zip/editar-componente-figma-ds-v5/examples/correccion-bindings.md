# Corrección de una migración incompleta

Usa esta instrucción cuando una primera migración quedó visualmente parecida, pero con bindings incorrectos:

```text
La migración anterior no cumple el Design System. No cambies el alcance ni rediseñes el componente. Corrige la copia existente usando las fuentes oficiales permanentes registradas en la skill.

Problemas detectados:
- Los iconos están vinculados a una librería distinta de DS Token · Prime.
- Las capas de texto tienen valores tipográficos locales y no Text Styles de DS Components · Prime.
- Padding y gaps no están vinculados a variables de spacing.
- Se aplicaron fondos negros o grafito, pero el componente debe funcionar en Light sobre fondo blanco.

Antes de editar, identifica y muéstrame:
1. icono oficial exacto ubicado en DS Token · Prime para cada reemplazo;
2. Text Style exacto ubicado en DS Components · Prime para cada capa de texto;
3. variable exacta para cada padding y gap;
4. variables semánticas de surface, content, border y estados para Light / fondo blanco.

No uses aproximaciones visuales. No copies solo números o propiedades. Debes realizar bindings reales.

Después de mostrar el mapa, espera mi aprobación. Al finalizar, ejecuta la puerta de aceptación de la skill y no declares terminado si queda un icono externo, un texto sin Text Style o un spacing local cuando exista variable.
```
