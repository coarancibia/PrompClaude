# Instalación en Claude Code desde Terminal

Esta versión reemplaza la skill anterior y mantiene el mismo comando:

```text
/editar-componente-figma-ds
```

## Reemplazar la versión anterior

1. Guarda `editar-componente-figma-ds-v5.zip` en:

```text
~/Desktop/Claude/skill/
```

2. Sal de Claude Code:

```text
/exit
```

3. En la Terminal del Mac ejecuta:

```bash
mkdir -p ~/.claude/skills
rm -rf ~/.claude/skills/editar-componente-figma-ds
unzip -o ~/Desktop/Claude/skill/editar-componente-figma-ds-v5.zip -d ~/.claude/skills
```

4. Comprueba la versión:

```bash
grep -n 'version:' ~/.claude/skills/editar-componente-figma-ds/SKILL.md
```

Debe aparecer:

```text
version: "5.0"
```

5. Abre Claude desde tu carpeta de trabajo:

```bash
cd ~/Desktop/Claude
claude
```

## Cómo invocarla

Para migrar un componente:

```text
/editar-componente-figma-ds

Componente a migrar:
[link exacto del componente]

Objetivo:
[ajuste específico, solo cuando sea necesario]
```

Para crear un componente:

```text
/editar-componente-figma-ds

Componente a crear:
[descripción de su función, contenido y estados necesarios]
```

La skill ya contiene permanentemente:

- el enlace de DS Token · Prime;
- el enlace de DS Components · Prime;
- el modo Light;
- la superficie de fondo blanco;
- la jerarquía de reutilización de átomos, moléculas y organismos.

Claude debe analizar primero y pedir aprobación antes de modificar Figma.
