---
name: editar-componente-figma-ds
description: "Audita, actualiza o crea cualquier componente o component set de Figma para alinearlo con los tokens, variables, estilos, componentes y criterios de accesibilidad vigentes del Design System Prime. Úsalo para botones, inputs, tabs, cards, modales, alertas, selectores, navegación, loaders y cualquier otro componente. Siempre trabaja primero en modo lectura, presenta el diagnóstico y solicita aprobación explícita antes de modificar Figma."
argument-hint: "[link exacto del componente o descripción del componente a crear] [objetivo opcional]"
disable-model-invocation: true
compatibility: "Requires the Figma MCP server with read access; write actions require edit permission and the official Figma write capability available in Claude Code."
metadata:
  version: "5.0"
  mcp-server: figma
  workflow: fixed-ds-sources-typography-preflight-audit-source-map-approve-duplicate-edit-readback-audit
---

# Editar o crear cualquier componente de Figma con el Design System Prime

Revisa, migra o crea un componente usando las fuentes oficiales fijas del Design System Prime, manteniendo su función, estructura, variantes, comportamiento responsive y accesibilidad.

Esta skill es **genérica**. No está asociada a un tipo de componente específico. Debe adaptar la auditoría al componente que reciba o se solicite crear: botón, input, select, tab, card, tooltip, modal, toast, checkbox, radio, switch, acordeón, navegación, loader u otro. Debe trabajar con átomos, moléculas y organismos respetando la jerarquía de reutilización definida en esta skill.

## Principio principal

**Nunca modifiques Figma inmediatamente.**

Aunque la usuaria pida “actualízalo”, “cámbialo” o “aplica el nuevo DS”, primero debes:

1. inspeccionar;
2. diagnosticar;
3. mapear los tokens y componentes correctos;
4. explicar los cambios propuestos;
5. pedir aprobación explícita;
6. trabajar sobre una copia por defecto.

## Límites obligatorios

1. Trabaja únicamente sobre el nodo, componente o component set enlazado y sus dependencias mínimas.
2. No inspecciones toda una página si basta con revisar el componente, sus variantes, instancias anidadas y colecciones de variables relacionadas.
3. Durante la auditoría no escribas, dupliques, renombres, muevas, elimines, publiques ni modifiques ningún nodo.
4. No edites el componente original por defecto.
5. No edites componentes maestros publicados ni librerías externas sin doble confirmación.
6. No desprendas instancias.
7. No conviertas componentes en frames ni los reconstruyas con formas sueltas si existe una estructura reutilizable.
8. No reemplaces valores por aproximaciones visuales. Mapea cada elemento por su función semántica.
9. No inventes tokens, variables, estilos, nombres de propiedades ni componentes.
10. Usa los nombres reales encontrados en el DS enlazado.
11. No uses valores hexadecimales, fuentes, tamaños, paddings, radios o efectos locales cuando exista un token o estilo equivalente.
12. No publiques la librería ni actualices masivamente las instancias al terminar.
13. Si un cambio requiere modificar un token global, detente y preséntalo como una decisión separada de gobernanza del DS.
14. Si el alcance es ambiguo, pregunta antes de asumir.

## Información mínima necesaria

Las fuentes del Design System y la superficie objetivo ya están registradas de forma permanente en esta skill. **No vuelvas a pedir sus enlaces ni el modo en cada ejecución.**

Para comenzar solo necesitas una de estas entradas:

- **Migración o actualización:** enlace exacto al componente o component set que se revisará.
- **Creación:** descripción clara del componente nuevo, su función y los estados necesarios.
- Objetivo específico, solo cuando no sea evidente.

La superficie objetivo es siempre **Light sobre fondo blanco**.

No consideres el color del canvas, de la página, de una captura o del frame contenedor como fuente de verdad. Aunque el componente original o la página estén sobre negro o grafito, debes aplicar los tokens semánticos correspondientes a Light / fondo blanco.

Si no puedes acceder a una de las dos fuentes oficiales fijas mediante Figma MCP, informa qué archivo no está accesible y detente antes de editar. No pidas a la usuaria que vuelva a pegar enlaces que ya están registrados y no completes el trabajo con aproximaciones visuales.


## Mapa fijo de fuentes del Design System

Para este sistema, usa siempre estas fuentes permanentes y no las cambies por inferencia:

### DS Token · Prime

URL oficial fija:

`https://www.figma.com/design/mMM5ogwjtFkvYkaIJliy3g/Ds-Token-%C2%B7-Prime?node-id=0-1&t=Qthju29IpxPanHa7-1`

Debes consultar este archivo en cada ejecución para confirmar los recursos vigentes necesarios para el componente. Es la fuente de verdad para:

- variables de color y aliases semánticos;
- modos Light y Dark;
- variables de spacing, padding y gap;
- variables de radius, sizing, stroke, opacity y efectos cuando existan;
- **iconografía oficial**, incluidos los componentes o instancias de iconos disponibles en ese archivo.

### DS Components · Prime

URL oficial fija:

`https://www.figma.com/design/7bkszPkRwUCHA5K9ZTIEfR/Ds-Components-%C2%B7-Prime?node-id=0-1&t=pY48ErvconPlP4Ss-1`

Debes consultar este archivo en cada ejecución para confirmar los recursos vigentes necesarios para el componente. Es la fuente de verdad para:

- **Text Styles oficiales**;
- componentes y component sets oficiales;
- variantes, propiedades y patrones reutilizables.

Reglas de procedencia:

- No busques Text Styles en DS Token.
- No busques iconos en DS Components.
- No uses una librería externa de iconos aunque visualmente coincida.
- No recrees manualmente un Text Style ni un icono cuando exista su recurso oficial.
- Si no puedes confirmar un recurso en su archivo correspondiente, marca `sin equivalencia confirmada` y detente antes de editar.


## Puerta tipográfica obligatoria

La tipografía no se considera migrada por coincidir visualmente con la familia, peso, tamaño, line-height o letter-spacing. **Cada capa de texto debe quedar vinculada de forma nativa a un Text Style publicado de `DS Components · Prime`.**

Antes de editar cualquier componente, ejecuta un **preflight tipográfico**:

1. Enumera todas las capas de texto del componente y de todas sus variantes.
2. Registra para cada capa:
   - nombre de la capa;
   - variante o estado donde aparece;
   - texto de ejemplo;
   - Text Style actual, si existe;
   - familia, peso, tamaño y line-height actuales;
   - rol semántico detectado: label, body, title, helper, error, caption u otro.
3. Consulta `DS Components · Prime` y encuentra el Text Style publicado exacto para cada rol.
4. Presenta el nombre real del Text Style de destino. No aceptes descripciones genéricas como “Label Medium” si no coinciden con el nombre publicado.
5. Si una capa no tiene equivalencia confirmada, marca `SIN TEXT STYLE CONFIRMADO` y no edites hasta que la usuaria defina el mapeo.
6. Confirma que la biblioteca `DS Components · Prime` esté publicada, accesible y habilitada en el archivo de destino. Si no está habilitada, informa este bloqueo antes de editar.

Tabla obligatoria previa a la aprobación:

| Capa de texto | Variante/estado | Text Style actual | Text Style exacto de destino en DS Components · Prime | Biblioteca habilitada | Acción |
|---|---|---|---|---|---|

Durante la ejecución:

- Aplica el Text Style como **estilo nativo vinculado**.
- No copies manualmente font family, weight, size, line-height, letter-spacing o case para simular el estilo.
- No crees Text Styles locales nuevos.
- No dejes estilos mixtos parciales dentro de una misma capa salvo que estén documentados y aprobados.
- Conserva el contenido y las propiedades de texto editables del componente.
- Si Figma MCP no puede aplicar el estilo vinculado, detente y reporta la limitación; no reemplaces por valores locales.

Después de editar, realiza una **lectura de comprobación** del componente resultante:

1. Vuelve a inspeccionar todas las capas de texto.
2. Informa el nombre exacto del Text Style realmente vinculado a cada una.
3. Compara el resultado con el mapeo aprobado.
4. Si alguna capa muestra valores locales, un estilo heredado, un estilo de otra biblioteca o `Mixed`, clasifica el trabajo como **INCOMPLETO**.
5. No declares finalizada la migración hasta obtener `100 %` de capas aplicables vinculadas a Text Styles de `DS Components · Prime`.

## Superficie y modo permanentes

- Modo obligatorio: **Light**.
- Superficie de uso: **fondo blanco**.
- No solicites a la usuaria elegir entre Light y Dark.
- No heredes fills negros o grafito desde el componente original, el canvas, una captura o una página de documentación.
- Usa variables semánticas Light para surface, content, border, focus, selected, disabled, error y cualquier otro estado aplicable.
- Solo puedes usar una superficie oscura cuando sea parte intrínseca y explícita del propio componente —por ejemplo, un overlay documentado— y exista un token oficial que lo justifique. Debes informarlo en la propuesta.

## Jerarquía obligatoria: átomos, moléculas y organismos

Antes de crear, migrar o reconstruir un componente, sigue este orden:

1. Busca en **DS Components · Prime** si ya existe el componente completo y vigente.
2. Si existe, reutilízalo o propón extenderlo; no lo reconstruyas con capas sueltas.
3. Si no existe, busca componentes anidados equivalentes y reutiliza los existentes.
4. Clasifica el resultado como átomo, molécula u organismo según su función y composición.
5. Para una molécula, reutiliza átomos oficiales como instancias vinculadas.
6. Para un organismo, reutiliza moléculas y átomos oficiales como instancias vinculadas.
7. Obtén iconos exclusivamente desde **DS Token · Prime**.
8. Aplica Text Styles exclusivamente desde **DS Components · Prime**.
9. Aplica variables exclusivamente desde **DS Token · Prime**.
10. Crea un componente nuevo solo cuando no exista una equivalencia funcional aprobada.

Reglas de composición:

- No hagas detach de instancias.
- No copies visualmente un componente oficial para simularlo.
- No conviertas átomos o moléculas existentes en grupos o frames sueltos.
- Conserva instance swap, propiedades de texto, booleanas y variantes cuando corresponda.
- Si una necesidad requiere modificar la API de un componente base, preséntala como decisión de gobernanza antes de editar.

## Flujo obligatorio

### Fase 1 — Comprensión del componente

Identifica primero qué tipo de componente es y cuál es su función dentro del producto.

Registra:

- nombre y ubicación;
- si es componente individual o component set;
- propósito funcional;
- variantes y propiedades;
- estados disponibles;
- componentes e iconos anidados;
- variables, estilos y valores locales actuales;
- Auto Layout, constraints, min/max width, wrapping y resizing;
- dependencias con librerías;
- contenido editable;
- interacciones o prototipos asociados;
- riesgos de impacto sobre instancias existentes.

No asumas estados o propiedades solo porque son comunes en otros componentes. Descubre qué existe realmente.

### Fase 2 — Auditoría del DS vigente

Antes de proponer cambios, identifica y declara las fuentes de verdad exactas respetando el mapa fijo del sistema:

- en **DS Token · Prime**: colección y modo de variables de color;
- en **DS Token · Prime**: colección de variables de spacing, sizing, radius, stroke, opacity y efectos;
- en **DS Token · Prime**: página, set o componente exacto de cada icono oficial;
- en **DS Components · Prime**: archivo y nombres exactos de los Text Styles;
- en **DS Components · Prime**: componentes oficiales y componentes anidados.

No reutilices una librería solo porque ya está vinculada al componente original. Una dependencia existente puede ser precisamente lo que debe migrarse.

Inspecciona solamente los elementos necesarios del nuevo DS y busca equivalencias reales para:

- color de superficies;
- color de contenido y texto;
- bordes, strokes e indicadores;
- tipografía;
- iconografía;
- spacing, padding y gap;
- tamaños mínimos y máximos;
- radios;
- elevación, sombras y overlays;
- opacidades;
- componentes anidados;
- estados interactivos;
- modo Light y superficie blanca;
- marcas, plataformas o densidades;
- reglas responsive.

Usa este orden de preferencia:

1. componente oficial vigente de **DS Components · Prime**;
2. Text Style oficial de **DS Components · Prime** para toda capa de texto;
3. token o variable semántica;
4. alias semántico por modo, marca o plataforma;
5. token primitivo documentado;
6. valor local, solo si la usuaria aprueba explícitamente una excepción.

Reglas de bloqueo:

- Si existe un Text Style aplicable, está prohibido recrearlo con familia, peso, tamaño o line-height locales.
- Si existe una variable de spacing aplicable, está prohibido escribir padding o gap como número local.
- Si existe una variable de color aplicable, está prohibido usar hex, RGB, opacidad local o un estilo de otra colección.
- Si existe un icono oficial en **DS Token · Prime**, está prohibido conservar, copiar o insertar un icono proveniente de otra librería o de DS Components.
- Si la herramienta no permite realizar un binding real, no simules el resultado. Detente, informa la limitación y deja ese punto pendiente de ejecución manual.

Lee [references/migration-rules.md](references/migration-rules.md) para aplicar las reglas de migración.

### Fase 3 — Revisión adaptada al tipo de componente

Define los criterios específicos según la función detectada.

Ejemplos:

- **Botones:** jerarquía, tamaños, iconos, loading, focus, disabled y ancho.
- **Inputs y selects:** label, helper, error, placeholder, focus, disabled, filled y validación.
- **Tabs y navegación:** selected, focus, indicador, distribución, labels largas y semántica.
- **Checkbox, radio y switch:** estados, área interactiva, contraste, etiqueta y selección.
- **Cards:** estructura, slots, acciones, jerarquía, padding, responsive y estados clickeables.
- **Modales y drawers:** overlay, foco, cierre, ancho, jerarquía, scroll y acciones.
- **Alertas y toasts:** rol, icono, contraste, contenido, acción y cierre.
- **Tooltips:** activación, contenido, contraste, posición y comportamiento responsive.
- **Loaders y progress:** movimiento, tamaño, contraste y comunicación del estado.

La lista anterior orienta la auditoría, pero no obliga a crear estados ni propiedades que el componente no necesite.

Lee [references/accessibility-components.md](references/accessibility-components.md) para aplicar una revisión de accesibilidad general y por tipo de componente.

### Fase 4 — Detección de problemas

Identifica como mínimo:

- valores hardcodeados;
- variables o estilos obsoletos;
- bindings al modo o colección incorrecta;
- tokens primitivos usados cuando existe un token semántico;
- tipografía sin estilo o con mezcla de estilos;
- iconos sueltos cuando existe un componente oficial;
- nombres de propiedades inconsistentes;
- variantes duplicadas o combinatorias innecesarias;
- estados faltantes que sí sean necesarios para la función;
- estados visualmente indistinguibles;
- problemas de contraste;
- información comunicada solo mediante color;
- áreas interactivas insuficientes;
- Auto Layout incorrecto;
- width/height rígidos sin justificación;
- problemas con labels cortas o largas;
- dependencias que podrían romper instancias existentes.

No corrijas todavía.

### Fase 5 — Propuesta previa obligatoria

Entrega un informe breve y claro con este formato:

#### 1. Alcance detectado

- Componente exacto.
- Tipo y función.
- Fuente de verdad del DS.
- Modos, marcas, variantes y estados incluidos.
- Elementos fuera de alcance.

#### 2. Qué se conservará

- Estructura correcta.
- Propiedades útiles.
- Variantes válidas.
- Componentes anidados que ya cumplen el DS.
- Comportamiento responsive correcto.

#### 3. Problemas detectados

Agrupa los hallazgos en:

- tokens y estilos;
- estructura del componente;
- variantes y propiedades;
- responsive y Auto Layout;
- accesibilidad;
- impacto potencial sobre instancias.

#### 4. Mapeo propuesto

Usa una tabla:

| Elemento o estado | Valor actual | Token, estilo o componente real del nuevo DS | Cambio propuesto | Motivo |
|---|---|---|---|---|

Incluye solo las categorías aplicables al componente, por ejemplo:

- surface;
- content/text;
- border/indicator;
- icon;
- typography;
- spacing;
- sizing;
- radius;
- elevation;
- focus;
- selected;
- hover;
- pressed;
- disabled;
- error;
- loading.

No escribas nombres ficticios como `color.primary.500`. Si no encontraste el token real, indica **“sin equivalencia confirmada”**.

Añade también una tabla de procedencia y binding:

| Capa o propiedad | Fuente aprobada | Binding esperado | Estado previo a edición |
|---|---|---|---|

Debe incluir, como mínimo, textos, iconos, fills, strokes, padding, gap, radius y tamaños aplicables.

#### 5. Cambios estructurales

Explica:

- propiedades y variantes que se mantienen;
- propiedades que se propone renombrar, agregar o eliminar;
- componentes anidados que se propone sustituir;
- impacto sobre instancias existentes;
- decisiones que necesitan validación de Design System.

#### 6. Accesibilidad

Informa:

- contraste;
- diferenciación de estados;
- focus visible;
- área interactiva;
- legibilidad y escalabilidad del contenido;
- uso de color, iconos y etiquetas;
- comportamiento de teclado o semántica que debe anotarse para desarrollo;
- puntos que Figma no permite validar completamente.

#### 7. Plan de ejecución

Enumera exactamente:

- qué se duplicará;
- qué cambiará en la copia;
- qué no se tocará;
- cómo se validará el resultado.

Termina siempre con esta pregunta y detente:

> **No he modificado Figma. ¿Qué deseas hacer?**
> 1. `APROBAR COPIA`: duplicar el componente y aplicar la propuesta en la copia.
> 2. `AJUSTAR PROPUESTA`: modificar el mapeo o el alcance antes de editar.
> 3. `EDITAR ORIGINAL`: analizar impacto y pedir una segunda confirmación.
> 4. `CANCELAR`: no realizar cambios.

No ejecutes ninguna escritura en el mismo turno de la propuesta.

### Fase 6 — Ejecución después de la aprobación

#### Cuando la usuaria responde `APROBAR COPIA`

1. Confirma que la capacidad de escritura de Figma esté disponible.
2. Duplica únicamente el componente o component set aprobado.
3. Mantén el original intacto.
4. Ubica la copia en una sección de trabajo existente.
5. Si no existe una sección WIP, crea una sin reorganizar el resto de la página.
6. Usa la convención de naming existente.
7. Si no existe una convención clara, usa temporalmente:

   `WIP_AI/<nombre-original>/DS-migration`

8. Conserva la API del componente siempre que sea posible:
   - propiedades;
   - valores;
   - descripciones;
   - relaciones entre variantes;
   - nested instances;
   - instance swaps.
9. Aplica únicamente los cambios aprobados.
10. Vincula los tokens, estilos y componentes reales del nuevo DS.
11. Para cada capa de texto, aplica el **Text Style publicado exacto de DS Components · Prime como vínculo nativo**; no basta con copiar sus valores tipográficos. Luego vuelve a leer la capa y confirma el nombre del estilo realmente aplicado.
12. Para padding, gap, radius, sizing y stroke, vincula las variables reales disponibles; no basta con replicar el número.
13. Para cada icono, usa una instancia del icono oficial encontrado en **DS Token · Prime** y conserva su capacidad de instance swap cuando corresponda.
14. Aplica colores semánticos del modo Light y superficie blanca. No heredes negro, grafito u otro color desde el canvas, el frame contenedor o la captura.
15. No agregues estados “por si acaso” ni componentes anidados que no estén justificados por la función.
16. No desprendas instancias.
17. No publiques la librería.
18. No actualices otras pantallas ni instancias fuera del alcance.

#### Cuando la usuaria responde `EDITAR ORIGINAL`

1. No edites todavía.
2. Inspecciona dependencias, instancias y alcance de propagación.
3. Explica qué pantallas o componentes podrían verse afectados.
4. Solicita una segunda confirmación exacta:

> `CONFIRMO EDITAR ORIGINAL`

5. Solo después de esa confirmación aplica exclusivamente los cambios aprobados.

### Fase 7 — Validación obligatoria

Después de editar, valida:

- que el original permanezca intacto cuando se trabajó sobre una copia;
- que ninguna instancia se haya desprendido;
- que las variantes y propiedades sigan funcionando;
- que no existan valores locales cuando haya token, variable o estilo disponible;
- que cada variable apunte al modo y colección correctos;
- que **todas las capas de texto aplicables estén vinculadas a Text Styles reales**, no solo visualmente igualadas;
- que **todos los iconos provengan de DS Token** y no de DS Components, una librería heredada o una librería externa;
- que padding, gap, radius, sizing y stroke estén vinculados a variables cuando existan;
- que los colores correspondan al modo Light y superficie blanca y no al fondo visual del canvas;
- que los componentes anidados sean los oficiales;
- que Auto Layout, Hug, Fill, Fixed, min/max width y wrapping funcionen correctamente;
- que el componente resista contenido corto y largo;
- que los estados aplicables sean perceptibles y coherentes;
- que focus y selected no se confundan;
- que la información no dependa solo del color;
- que contraste y área interactiva cumplan el criterio acordado;
- que no se hayan creado variables, estilos o componentes huérfanos;
- que no se haya publicado la librería.

### Puerta de aceptación obligatoria

No declares el trabajo terminado si falla cualquiera de estos puntos:

- `0` iconos provenientes de librerías no aprobadas;
- `100 %` de las capas de texto aplicables vinculadas a Text Styles del DS;
- `100 %` de fills y strokes aplicables vinculados a variables del modo correcto;
- `100 %` de padding y gap vinculados a variables cuando el DS disponga de ellas;
- ningún fondo negro o grafito salvo que corresponda al token semántico de la superficie objetivo;
- ninguna sustitución visual que imite un token, estilo o componente sin estar realmente vinculada.

Si queda una excepción, clasifica el resultado como **incompleto**, identifica la capa exacta y solicita una decisión o corrección.

Si una escritura falla:

1. detente;
2. revisa el estado parcial;
3. identifica duplicados o nodos huérfanos;
4. limpia el intento parcial antes de reintentar;
5. informa qué ocurrió;
6. no repitas la acción a ciegas.

## Entrega final

Informa:

- nombre y enlace del componente resultante;
- si se modificó una copia o el original;
- tokens, variables, estilos y componentes aplicados;
- propiedades o variantes modificadas;
- validaciones responsive realizadas;
- comprobaciones de accesibilidad;
- diferencias respecto del plan aprobado;
- pendientes manuales;
- decisiones para el equipo de Design System;
- confirmación de que la librería no fue publicada;
- auditoría final de bindings con el total de capas revisadas y cualquier valor local restante;
- tabla final capa por capa con el nombre exacto del Text Style realmente vinculado y confirmación de que proviene de DS Components · Prime;
- nombre exacto del icono y su ubicación en DS Token, colección de variables, modo y Text Styles utilizados desde DS Components · Prime.

## Ejemplo de uso

Consulta [examples/uso-general.md](examples/uso-general.md).

La usuaria no debe volver a entregar los enlaces de DS Token · Prime ni DS Components · Prime. Ambos están registrados en esta skill.

Argumentos recibidos al invocar la skill:

$ARGUMENTS
