# Reglas generales de migración al Design System

## 1. Orden de preferencia

1. Componente oficial vigente.
2. Token o variable semántica vigente.
3. Alias semántico por modo, marca o plataforma.
4. Token primitivo documentado.
5. Valor local, solo como excepción informada.

## 2. Mapeo semántico

- Mapea por función y no por parecido visual.
- No reemplaces un color antiguo por el hex más cercano sin confirmar su rol.
- Ejemplos de roles: `surface`, `content`, `border`, `action`, `selected`, `disabled`, `focus`, `error`, `success`.
- Comprueba el comportamiento de cada variable en todos los modos aplicables.

## 3. Color

- Vincula fills, strokes, texto, iconos, indicadores, focus y overlays a variables reales.
- Evita colores locales cuando exista una variable semántica.
- No uses opacity para simular un estado si el DS tiene un token específico.
- Distingue correctamente `disabled`, `unselected`, `secondary` y `subtle`.
- No uses el color del canvas o del frame externo para inferir el tema.
- Para una superficie `Light / fondo blanco`, usa los tokens semánticos de ese modo; no arrastres fondos negros o grafito desde capturas o componentes anteriores.

## 4. Tipografía

- Toda capa de texto aplicable debe quedar vinculada a un **Text Style real** del DS.
- Copiar familia, peso, tamaño y line-height no equivale a aplicar el Text Style.
- Si no puedes realizar el binding, informa la limitación y no lo marques como resuelto.
- Usa el estilo semántico correspondiente al rol del contenido.
- Revisa familia, tamaño, peso, line-height, letter-spacing y text case.
- No asumas equivalencias solo por el nombre del estilo antiguo.
- Detecta fuentes faltantes o estilos mezclados dentro de una misma capa.
- Conserva jerarquía y legibilidad en labels largas y cortas.

## 5. Iconografía

- La iconografía oficial está en **DS Token**.
- Usa exclusivamente los componentes o instancias de iconos encontrados en DS Token.
- No busques ni tomes iconos desde DS Components.
- No conserves un icono de otra librería solo porque ya está anidado en el componente original.
- Registra el nombre exacto del icono y su ubicación dentro de DS Token.
- Reutiliza el componente de icono oficial.
- Conserva instance swap cuando el icono deba ser configurable.
- Respeta caja, tamaño, alineación óptica y token de color.
- No pegues SVG o vectores sueltos si existe el icono oficial.

## 6. Espaciado, tamaño y radio

- Vincula padding, gap, min-height, tamaño de icono, stroke, radio y elevación a variables cuando existan.
- Copiar el valor numérico no equivale a vincular la variable.
- Al terminar, verifica individualmente los bindings de Auto Layout.
- Mantén la escala oficial del DS.
- No redondees silenciosamente valores sin equivalencia.
- Cuando no exista un token exacto, reporta la diferencia y espera aprobación.

## 7. Component properties y variantes

- Preserva la API del componente cuando sea posible.
- Antes de renombrar una propiedad o valor, informa el impacto en instancias.
- Evita variantes combinatorias innecesarias.
- Usa propiedades boolean, text, instance swap o nested instances cuando corresponda.
- No elimines variantes sin comprobar el component set completo.
- No agregues hover, pressed, loading u otros estados si no están definidos por la función o por el DS.

## 8. Auto Layout y responsive

- Mantén Hug, Fill y Fixed con intención explícita.
- Evita posiciones absolutas salvo superposiciones necesarias.
- Valida min/max width, wrapping, alignment, distribución, padding y gaps.
- Prueba contenido corto y largo.
- Prueba los anchos o breakpoints pertinentes sin ampliar el alcance innecesariamente.

## 9. Componentes anidados

- Sustituye nested instances solo por equivalentes oficiales.
- Conserva las propiedades que permitan configurar contenido, iconos o estados.
- No rompas instance swaps existentes.
- No conviertas componentes reutilizables en grupos o frames sin justificación.

## 10. Seguridad y gobernanza

- La copia de trabajo es el comportamiento predeterminado.
- El original requiere doble confirmación.
- No publiques cambios.
- No actualices instancias fuera del alcance.
- No modifiques tokens globales como parte de una migración local.
- Convierte cualquier cambio global en una propuesta separada de gobernanza.
