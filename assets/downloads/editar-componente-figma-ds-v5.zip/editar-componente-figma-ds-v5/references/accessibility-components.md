# Accesibilidad para componentes de interfaz

Esta referencia sirve para cualquier tipo de componente. Adapta la revisión a su función y no agregues estados o comportamientos que no correspondan.

Figma permite validar principalmente la capa visual y estructural. La semántica, los roles, el teclado, los lectores de pantalla y el comportamiento final deben quedar documentados para desarrollo.

## 1. Contraste

- Texto normal: objetivo mínimo 4.5:1 respecto del fondo.
- Texto grande: objetivo mínimo 3:1.
- Iconos funcionales, bordes esenciales, indicadores y focus: objetivo mínimo 3:1 respecto de colores adyacentes.
- El componente debe conservar contraste en los modos y temas aplicables.
- Los estados selected, error, success, warning o focus no deben depender exclusivamente del color.

## 2. Estados

Evalúa únicamente los estados necesarios para la función, por ejemplo:

- default;
- hover;
- pressed;
- focus visible;
- selected;
- disabled;
- error;
- success;
- loading;
- expanded/collapsed;
- checked/unchecked/indeterminate.

No confundas:

- selected con focus;
- disabled con unselected;
- error con warning;
- loading con disabled.

Cada estado debe tener una señal perceptible y consistente con el DS.

## 3. Área interactiva

- Revisa la política de tamaño mínimo definida por el DS.
- Cuando el DS no tenga una regla explícita, marca como riesgo los targets menores a 24 × 24 CSS px.
- Para interfaces táctiles, recomienda una superficie mayor cuando el contexto lo permita.
- La zona clickeable debe cubrir el contenedor completo del control, no solo el texto o el icono.

## 4. Focus visible

- Todo control interactivo debe contemplar un estado de foco visible.
- Focus no debe depender únicamente de un cambio sutil de color.
- El indicador debe conservar contraste y no quedar recortado por el frame.
- Documenta el orden de navegación cuando el componente forme parte de un patrón complejo.

## 5. Texto, labels y contenido

- No uses placeholder como reemplazo de label cuando el control requiera identificación persistente.
- Evita depender solo de iconos cuando el significado no sea universal.
- Comprueba labels cortas, largas, saltos de línea y aumento de contenido.
- No trunques información esencial sin una alternativa accesible.
- Mantén un orden de lectura lógico.

## 6. Errores y validación

Para inputs, selects, formularios y controles relacionados:

- el error debe incluir texto comprensible;
- el estado no debe comunicarse solo con color;
- el mensaje debe quedar asociado visual y funcionalmente al campo;
- distingue helper, warning y error;
- conserva el valor ingresado cuando sea posible.

## 7. Componentes por patrón

### Botones y acciones

- Jerarquía clara entre acciones.
- Label legible y comprensible.
- Focus, pressed, disabled y loading diferenciados.
- Icon-only requiere nombre accesible documentado.

### Inputs y selects

- Label persistente.
- Estados default, focus, filled, disabled y error según necesidad.
- Helper y error legibles.
- Indicador de obligatoriedad comprensible.

### Tabs y navegación

- Selected y focus son distintos.
- El estado activo no depende solo del color.
- Labels largas no rompen la distribución.
- Documenta navegación por teclado y asociación con contenido para desarrollo.

### Checkbox, radio y switch

- Control y label forman una única área interactiva.
- Checked, unchecked, indeterminate y disabled se distinguen claramente.
- No uses switch para una acción que no represente encendido/apagado inmediato.

### Modales y drawers

- Acción de cierre visible.
- Jerarquía clara de título, contenido y acciones.
- Documenta manejo del foco, bloqueo del fondo y retorno del foco.
- Evita que el contenido quede inaccesible por scroll.

### Alerts y toasts

- Mensaje comprensible.
- Icono y color no son la única señal.
- Acción y cierre son accesibles cuando existen.
- Documenta prioridad y anuncio para tecnologías de asistencia.

### Tooltips

- No deben contener información esencial que no exista en otro lugar.
- Deben considerar mouse, teclado y tacto.
- Contraste y legibilidad suficientes.

### Cards clickeables

- Evita múltiples áreas interactivas superpuestas sin jerarquía.
- Define qué zona es clickeable.
- Conserva focus visible y orden lógico.

## 8. Handoff a desarrollo

Cuando aplique, documenta:

- rol o patrón esperado;
- nombre accesible;
- estado comunicado;
- navegación por teclado;
- comportamiento del foco;
- relación con labels, paneles o mensajes;
- comportamiento responsive;
- estados que no pueden representarse completamente en Figma.
